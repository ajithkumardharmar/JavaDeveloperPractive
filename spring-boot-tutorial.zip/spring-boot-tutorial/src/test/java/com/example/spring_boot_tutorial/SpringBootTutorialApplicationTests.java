package com.example.spring_boot_tutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
