package com.springboot.MangoDBTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MangoDbTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
